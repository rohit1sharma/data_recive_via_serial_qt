#include "mainwindow.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
     w.setWindowTitle("random data from serial");
    w.setFixedSize(400,112);


    w.show();
    return a.exec();
}
